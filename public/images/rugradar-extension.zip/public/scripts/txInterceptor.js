(function () {
  const originalRequest = window.ethereum.request;
  window.ethereum.request = async function (args) {
    if (args.method === "eth_sendTransaction") {
      const tx = args.params[0];
      window.postMessage({ type: "INTERCEPT_TX", tx }, "*");
    }
    return originalRequest.apply(this, arguments);
  };

  window.addEventListener("message", (event) => {
    if (event.data.type === "INTERCEPT_TX") {
      chrome.runtime.sendMessage({ type: "INTERCEPT_TX", tx: event.data.tx });
    }
  });
})();