chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "INTERCEPT_TX") {
    console.log("Transaction intercepted in background:", message.tx);
  }
});