const script = document.createElement("script");
script.src = chrome.runtime.getURL("scripts/txInterceptor.js");
script.onload = () => script.remove();
(document.head || document.documentElement).append(script);