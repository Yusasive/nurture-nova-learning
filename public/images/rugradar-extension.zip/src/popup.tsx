import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";

const App = () => (
  <div className="p-4 text-sm">
    <h1 className="text-lg font-bold mb-2">🛡️ RugRadar</h1>
    <p>Monitoring your transaction for risks...</p>
  </div>
);

ReactDOM.createRoot(document.getElementById("root")!).render(<App />);